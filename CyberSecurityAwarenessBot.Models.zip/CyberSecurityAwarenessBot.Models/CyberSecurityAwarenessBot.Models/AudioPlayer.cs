﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwarenessBot.Models
{
    public static class AudioPlayer
    {
        public static void PlayGreeting(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    using (SoundPlayer player = new SoundPlayer(filePath))
                    {
                        player.Play();
                    }
                }
            }
            catch (Exception)
            {
                // Silently fail - audio is optional
            }
        }

        public static void PlaySoundAsync(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    using (SoundPlayer player = new SoundPlayer(filePath))
                    {
                        player.Play(); // Async playback
                    }
                }
            }
            catch (Exception)
            {
                // Silently fail
            }
        }
    }
}
