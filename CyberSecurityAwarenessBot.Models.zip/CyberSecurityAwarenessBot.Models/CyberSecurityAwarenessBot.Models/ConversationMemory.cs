﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwarenessBot.Models
{
    public class ConversationMemory
    {
        private Dictionary<string, string> _userInfo = new Dictionary<string, string>();
        private Queue<(string Topic, string Response)> _recentTopics = new Queue<(string, string)>();

        public void Remember(string key, string value)
        {
            if (_userInfo.ContainsKey(key))
                _userInfo[key] = value;
            else
                _userInfo.Add(key, value);
        }

        public string Recall(string key)
        {
            return _userInfo.ContainsKey(key) ? _userInfo[key] : string.Empty;
        }

        public void AddRecentTopic(string topic, string response)
        {
            _recentTopics.Enqueue((topic, response));
            if (_recentTopics.Count > 5)
                _recentTopics.Dequeue();
        }

        public (string Topic, string Response) GetLastTopic()
        {
            return _recentTopics.Count > 0 ? _recentTopics.Peek() : (string.Empty, string.Empty);
        }

        public bool HasRecentTopic => _recentTopics.Count > 0;
    }
}
