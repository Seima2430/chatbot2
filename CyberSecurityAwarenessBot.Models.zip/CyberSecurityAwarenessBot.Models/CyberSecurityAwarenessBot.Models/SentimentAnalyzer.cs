﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwarenessBot.Models
{
    public enum Sentiment
    {
        Positive,
        Worried,
        Frustrated,
        Curious,
        Neutral,
        Grateful
    }

    public class SentimentAnalyzer
    {
        private readonly Dictionary<string, Sentiment> _sentimentKeywords = new Dictionary<string, Sentiment>(StringComparer.OrdinalIgnoreCase)
        {
            // Worried keywords
            { "worried", Sentiment.Worried },
            { "scared", Sentiment.Worried },
            { "nervous", Sentiment.Worried },
            { "anxious", Sentiment.Worried },
            { "afraid", Sentiment.Worried },
            { "concerned", Sentiment.Worried },
            { "stress", Sentiment.Worried },
            { "overwhelmed", Sentiment.Worried },

            // Frustrated keywords
            { "frustrated", Sentiment.Frustrated },
            { "angry", Sentiment.Frustrated },
            { "annoyed", Sentiment.Frustrated },
            { "confused", Sentiment.Frustrated },
            { "difficult", Sentiment.Frustrated },
            { "hard", Sentiment.Frustrated },
            { "complicated", Sentiment.Frustrated },

            // Curious keywords
            { "curious", Sentiment.Curious },
            { "interested", Sentiment.Curious },
            { "tell me", Sentiment.Curious },
            { "learn", Sentiment.Curious },
            { "how", Sentiment.Curious },
            { "what", Sentiment.Curious },
            { "why", Sentiment.Curious },

            // Grateful/Positive keywords
            { "thank", Sentiment.Grateful },
            { "helpful", Sentiment.Grateful },
            { "great", Sentiment.Positive },
            { "good", Sentiment.Positive },
            { "awesome", Sentiment.Positive },
            { "perfect", Sentiment.Positive }
        };

        public Sentiment AnalyzeSentiment(string userInput)
        {
            string input = userInput.ToLower();

            foreach (var keyword in _sentimentKeywords)
            {
                if (input.Contains(keyword.Key))
                {
                    return keyword.Value;
                }
            }

            return Sentiment.Neutral;
        }

        public string GetEmpatheticResponse(Sentiment sentiment, string topicTip = "")
        {
            switch (sentiment)
            {
                case Sentiment.Worried:
                    return "It's completely understandable to feel worried. Cybersecurity threats can be intimidating. " +
                           "Let me share some practical tips to help you feel more secure. " + topicTip;

                case Sentiment.Frustrated:
                    return "I understand this can be frustrating. Cybersecurity takes time to master. " +
                           "Let me break this down simply for you. " + topicTip;

                case Sentiment.Curious:
                    return "That's great that you're curious! Learning about cybersecurity is the first step to staying safe. " +
                           topicTip;

                case Sentiment.Grateful:
                    return "You're very welcome! I'm glad I could help. " + topicTip;

                case Sentiment.Positive:
                    return "I'm happy to hear that! Staying positive about cybersecurity awareness is wonderful. " + topicTip;

                default:
                    return topicTip;
            }
        }
    }
}
