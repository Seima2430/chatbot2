﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwarenessBot.Models
{
    public class ResponseService
    {
        private readonly Random _random = new Random();
        private readonly SentimentAnalyzer _sentimentAnalyzer;
        private ConversationMemory _memory;
        private UserProfile _user;

        // Random response pools
        private readonly List<string> _phishingTips = new List<string>
        {
            "🔐 Phishing tip: Always check the sender's email address carefully - scammers often use addresses that look similar to real ones!",
            "📧 Phishing tip: Hover over links before clicking to see the actual URL destination.",
            "⚠️ Phishing tip: Legitimate companies will never ask for your password or OTP via email.",
            "🔍 Phishing tip: Look for spelling and grammar mistakes - these are common in phishing emails.",
            "⏰ Phishing tip: Be wary of emails creating URGENCY or threatening account closure."
        };

        private readonly List<string> _passwordTips = new List<string>
        {
            "🔑 Password tip: Use at least 12 characters with uppercase, lowercase, numbers, and symbols.",
            "🛡️ Password tip: Never reuse passwords across different accounts!",
            "💡 Password tip: Consider using a passphrase like 'PurpleElephantDances!23' - it's strong AND memorable.",
            "🔒 Password tip: Enable Two-Factor Authentication (2FA) whenever possible.",
            "📝 Password tip: Use a password manager to generate and store strong passwords."
        };

        private readonly List<string> _safeBrowsingTips = new List<string>
        {
            "🌐 Safe browsing tip: Always check for 'https://' and the padlock icon in the address bar.",
            "🛑 Safe browsing tip: Don't download attachments from unknown senders.",
            "🔔 Safe browsing tip: Keep your browser and antivirus software updated automatically.",
            "🚫 Safe browsing tip: Use ad-blockers to avoid malicious pop-up ads.",
            "📱 Safe browsing tip: Be careful when using public Wi-Fi - consider using a VPN."
        };

        private readonly List<string> _scamTips = new List<string>
        {
            "🎣 Scam tip: If an offer seems too good to be true, it probably is!",
            "📞 Scam tip: Never share OTPs, PINs, or banking details over the phone.",
            "💰 Scam tip: Be suspicious of unexpected prize winnings or lottery notifications.",
            "👔 Scam tip: Scammers often impersonate officials - verify through official channels.",
            "📧 Scam tip: Don't click links in SMS messages from unknown numbers."
        };

        // Generic greetings and responses
        private readonly List<string> _greetings = new List<string>
        {
            "Hello there! How can I help you stay safe online today?",
            "Hi! Ready to learn about cybersecurity?",
            "Greetings! Ask me anything about online safety.",
            "Hey there! What cybersecurity topic would you like to explore?"
        };

        // Keyword response mapping
        private readonly Dictionary<string, Func<string, string>> _keywordResponses;

        public ResponseService(UserProfile user, ConversationMemory memory)
        {
            _user = user;
            _memory = memory;
            _sentimentAnalyzer = new SentimentAnalyzer();

            _keywordResponses = new Dictionary<string, Func<string, string>>(StringComparer.OrdinalIgnoreCase)
            {
                { "password", (input) => GetRandomResponse(_passwordTips) },
                { "phishing", (input) => GetRandomResponse(_phishingTips) },
                { "scam", (input) => GetRandomResponse(_scamTips) },
                { "safe browsing", (input) => GetRandomResponse(_safeBrowsingTips) },
                { "browsing", (input) => GetRandomResponse(_safeBrowsingTips) },
                { "privacy", (input) => GetPrivacyResponse() },
                { "suspicious link", (input) => GetSuspiciousLinkResponse() },
                { "link", (input) => GetSuspiciousLinkResponse() }
            };
        }

        public string GetResponse(string userInput)
        {
            string input = userInput.Trim();
            _user.MessagesExchanged++;

            // Handle empty input
            if (string.IsNullOrWhiteSpace(input))
            {
                return "I didn't catch that. Could you please type your question?";
            }

            // Exit command
            if (input.Equals("exit", StringComparison.OrdinalIgnoreCase))
            {
                return $"Goodbye, {_user.Name}! Stay safe online! 👋";
            }

            // Analyze sentiment
            Sentiment sentiment = _sentimentAnalyzer.AnalyzeSentiment(input);

            // Check for follow-up questions (conversation flow)
            if (IsFollowUpQuestion(input) && _memory.HasRecentTopic)
            {
                var lastTopic = _memory.GetLastTopic();
                if (!string.IsNullOrEmpty(lastTopic.Topic))
                {
                    string followUpResponse = GetFollowUpResponse(lastTopic.Topic, input);
                    _memory.AddRecentTopic(lastTopic.Topic, followUpResponse);
                    return followUpResponse;
                }
            }

            // Handle "another tip" request
            if (input.Contains("another tip") || input.Contains("more tips") || input.Contains("tell me more"))
            {
                if (_memory.HasRecentTopic)
                {
                    var lastTopic = _memory.GetLastTopic();
                    return GetAnotherTip(lastTopic.Topic);
                }
                return "What topic would you like more tips about? Try asking about passwords, phishing, or safe browsing!";
            }

            // Check for user sharing interests (memory)
            if (input.Contains("interested in") || input.Contains("i like") || input.Contains("my favourite"))
            {
                return HandleInterestLearning(input);
            }

            // Check for greetings
            if (IsGreeting(input))
            {
                return GetRandomResponse(_greetings);
            }

            // Check how are you
            if (input.Contains("how are you"))
            {
                return $"I'm doing great, {_user.Name}! Thanks for asking. I'm here to help you with cybersecurity awareness.";
            }

            // Check purpose
            if (input.Contains("purpose") || input.Contains("what do you do"))
            {
                return "My purpose is to educate South African citizens about cybersecurity risks and help them stay safe online from scams, phishing, and other threats.";
            }

            // Check what can I ask
            if (input.Contains("what can i ask") || input.Contains("help"))
            {
                return GetHelpMessage();
            }

            // Check for keyword matches
            foreach (var keyword in _keywordResponses.Keys)
            {
                if (input.Contains(keyword))
                {
                    string response = _keywordResponses[keyword](input);
                    _memory.AddRecentTopic(keyword, response);

                    // Apply sentiment adjustment
                    if (sentiment != Sentiment.Neutral)
                    {
                        response = _sentimentAnalyzer.GetEmpatheticResponse(sentiment, response);
                    }

                    return response;
                }
            }

            // Check if asking about stored information (memory recall)
            if (input.Contains("my name") || input.Contains("remember me"))
            {
                return $"Of course I remember you! Your name is {_user.Name}. {GetRandomTipSuggestion()}";
            }

            // Default response for unrecognized input
            return "I'm not sure I understand. Can you try rephrasing? You can ask me about:\n" +
                   "• Password safety\n" +
                   "• Phishing scams\n" +
                   "• Safe browsing\n" +
                   "• Suspicious links\n" +
                   "• Online privacy\n\n" +
                   "Or type 'help' for more options!";
        }

        private string GetRandomResponse(List<string> responses)
        {
            return responses[_random.Next(responses.Count)];
        }

        private string GetRandomResponse(List<string> responses, string additionalContext)
        {
            return responses[_random.Next(responses.Count)] + " " + additionalContext;
        }

        private string GetPrivacyResponse()
        {
            string[] privacyTips = {
                "🔒 Privacy tip: Review your social media privacy settings regularly.",
                "🕵️ Privacy tip: Be careful what personal information you share online - birthday, address, phone number.",
                "📊 Privacy tip: Check which apps have access to your data and remove unnecessary permissions.",
                "🌍 Privacy tip: Use a VPN when browsing on public networks to protect your privacy."
            };
            return privacyTips[_random.Next(privacyTips.Length)];
        }

        private string GetSuspiciousLinkResponse()
        {
            string[] linkTips = {
                "🔗 Suspicious link tip: Hover over links to see the actual URL before clicking!",
                "⚠️ Link safety tip: Shortened URLs like bit.ly can hide dangerous destinations.",
                "🛡️ Link tip: When in doubt, type the website address manually instead of clicking links.",
                "📱 Link tip: On mobile, press and hold a link to preview the destination URL."
            };
            return linkTips[_random.Next(linkTips.Length)];
        }

        private bool IsGreeting(string input)
        {
            string[] greetings = { "hello", "hi", "hey", "good morning", "good afternoon", "good evening", "howdy" };
            foreach (var greet in greetings)
            {
                if (input.Contains(greet))
                    return true;
            }
            return false;
        }

        private bool IsFollowUpQuestion(string input)
        {
            string[] followUps = { "explain more", "tell me more", "more details", "elaborate", "what else", "go on" };
            foreach (var follow in followUps)
            {
                if (input.Contains(follow))
                    return true;
            }
            return false;
        }

        private string GetFollowUpResponse(string topic, string input)
        {
            switch (topic.ToLower())
            {
                case "password":
                    return "Let me elaborate on password safety! " + GetRandomResponse(_passwordTips) +
                           "\n\nWould you like another password tip? Just ask for 'another tip'!";
                case "phishing":
                    return "Here's more about phishing: " + GetRandomResponse(_phishingTips) +
                           "\n\nWant to learn more? Just ask for 'another tip'!";
                case "scam":
                    return "More scam awareness: " + GetRandomResponse(_scamTips) +
                           "\n\nShall I share another scam prevention tip?";
                default:
                    return GetRandomResponse(_greetings);
            }
        }

        private string GetAnotherTip(string topic)
        {
            switch (topic.ToLower())
            {
                case "password":
                    return GetRandomResponse(_passwordTips);
                case "phishing":
                    return GetRandomResponse(_phishingTips);
                case "scam":
                    return GetRandomResponse(_scamTips);
                case "safe browsing":
                    return GetRandomResponse(_safeBrowsingTips);
                default:
                    return GetRandomResponse(_phishingTips);
            }
        }

        private string HandleInterestLearning(string input)
        {
            if (input.Contains("password"))
            {
                _user.AddInterest("password safety");
                _memory.Remember("interest", "password safety");
                return "That's great! I'll remember you're interested in password safety. " +
                       GetRandomResponse(_passwordTips) +
                       "\n\nI'll keep this in mind for our future conversations!";
            }
            else if (input.Contains("phishing"))
            {
                _user.AddInterest("phishing awareness");
                _memory.Remember("interest", "phishing");
                return "Excellent! Learning about phishing is very important. " +
                       GetRandomResponse(_phishingTips) +
                       "\n\nI've noted your interest in phishing protection!";
            }
            else if (input.Contains("privacy"))
            {
                _user.AddInterest("privacy");
                _memory.Remember("interest", "privacy");
                return "Privacy is crucial in today's digital world! " + GetPrivacyResponse() +
                       "\n\nAs someone interested in privacy, I'll share relevant tips with you.";
            }
            else
            {
                return "That's wonderful! Cybersecurity awareness is valuable. Ask me for tips on specific topics like passwords or phishing!";
            }
        }

        private string GetHelpMessage()
        {
            return "📚 Here's what I can help you with:\n\n" +
                   "🔐 PASSWORD safety - Ask 'Tell me about password safety'\n" +
                   "🎣 PHISHING awareness - Ask 'What is phishing?'\n" +
                   "🛡️ SCAM prevention - Ask 'How to avoid scams?'\n" +
                   "🌐 SAFE BROWSING - Ask 'How do I browse safely?'\n" +
                   "🔗 SUSPICIOUS LINKS - Ask 'How to check suspicious links?'\n" +
                   "🔒 PRIVACY tips - Ask 'Tell me about privacy'\n\n" +
                   $"You can also tell me what topics you're interested in, and I'll remember! What would you like to learn about, {_user.Name}?";
        }

        private string GetRandomTipSuggestion()
        {
            string[] suggestions = {
                "Would you like to learn about password safety?",
                "Shall I share some phishing prevention tips?",
                "Interested in learning how to spot online scams?",
                "Want to know about safe browsing habits?"
            };
            return suggestions[_random.Next(suggestions.Length)];
        }
    }
}
