﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CyberSecurityAwarenessBot.Models
{
    public partial class MainForm : Form
    {
        private UserProfile _user;
        private ConversationMemory _memory;
        private ResponseService _responseService;

        // UI Controls
        private RichTextBox txtChatHistory;
        private TextBox txtUserInput;
        private Button btnSend;
        private Button btnClear;
        private Button btnExit;
        private Panel headerPanel;
        private Label lblTitle;
        private Label lblSubtitle;
        private PictureBox pbAsciiArt;
        private Panel inputPanel;
        private Label lblUserStatus;

        public MainForm()
        {
            InitializeComponent();
            InitializeChatbot();
            PlayWelcomeAudio();
            DisplayWelcomeMessage();
        }

        private void InitializeComponent()
        {
            this.Text = "Cybersecurity Awareness Bot - South Africa";
            this.Size = new Size(900, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(18, 25, 45);
            this.Font = new Font("Segoe UI", 10F);
            this.Icon = null;

            // Header Panel
            headerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 100,
                BackColor = Color.FromArgb(13, 18, 33)
            };

            lblTitle = new Label
            {
                Text = "🛡️ CYBERSECURITY AWARENESS BOT",
                ForeColor = Color.FromArgb(0, 255, 255),
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                Location = new Point(20, 20),
                AutoSize = true,
                BackColor = Color.Transparent
            };

            lblSubtitle = new Label
            {
                Text = "Stay Alert. Stay Secure. Stay Informed.",
                ForeColor = Color.FromArgb(0, 200, 100),
                Font = new Font("Segoe UI", 10, FontStyle.Italic),
                Location = new Point(25, 60),
                AutoSize = true,
                BackColor = Color.Transparent
            };

            headerPanel.Controls.Add(lblTitle);
            headerPanel.Controls.Add(lblSubtitle);

            // ASCII Art PictureBox (simulated as text)
            pbAsciiArt = new PictureBox
            {
                Dock = DockStyle.Top,
                Height = 80,
                BackColor = Color.FromArgb(13, 18, 33),
                Image = CreateAsciiArtImage()
            };
            pbAsciiArt.SizeMode = PictureBoxSizeMode.Zoom;

            // Chat History RichTextBox
            txtChatHistory = new RichTextBox
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(30, 35, 55),
                ForeColor = Color.White,
                Font = new Font("Consolas", 10),
                ReadOnly = true,
                BorderStyle = BorderStyle.None,
                ScrollBars = RichTextBoxScrollBars.Vertical
            };

            // Input Panel
            inputPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 80,
                BackColor = Color.FromArgb(13, 18, 33),
                Padding = new Padding(10)
            };

            txtUserInput = new TextBox
            {
                Location = new Point(10, 15),
                Size = new Size(650, 40),
                BackColor = Color.FromArgb(40, 45, 65),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Segoe UI", 11)
            };

            btnSend = new Button
            {
                Text = "📤 SEND",
                Location = new Point(670, 15),
                Size = new Size(90, 40),
                BackColor = Color.FromArgb(0, 150, 200),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnSend.FlatAppearance.BorderSize = 0;

            btnClear = new Button
            {
                Text = "🗑️ CLEAR",
                Location = new Point(770, 15),
                Size = new Size(90, 40),
                BackColor = Color.FromArgb(100, 100, 120),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnClear.FlatAppearance.BorderSize = 0;

            btnExit = new Button
            {
                Text = "❌ EXIT",
                Location = new Point(770, 15),
                Size = new Size(90, 40),
                BackColor = Color.FromArgb(200, 50, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Visible = false // Show only when needed
            };

            lblUserStatus = new Label
            {
                Text = "👤 Ready to chat",
                ForeColor = Color.FromArgb(150, 150, 180),
                Location = new Point(10, 55),
                AutoSize = true,
                Font = new Font("Segoe UI", 8)
            };

            inputPanel.Controls.Add(txtUserInput);
            inputPanel.Controls.Add(btnSend);
            inputPanel.Controls.Add(btnClear);
            inputPanel.Controls.Add(lblUserStatus);

            // Add controls to form
            this.Controls.Add(txtChatHistory);
            this.Controls.Add(inputPanel);
            this.Controls.Add(pbAsciiArt);
            this.Controls.Add(headerPanel);

            // Event handlers
            btnSend.Click += BtnSend_Click;
            btnClear.Click += BtnClear_Click;
            txtUserInput.KeyDown += TxtUserInput_KeyDown;
        }

        private PictureBox CreateAsciiArtImage()
        {
            // Create a bitmap with ASCII art text
            Bitmap bmp = new Bitmap(800, 80);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.FromArgb(13, 18, 33));
                string asciiArt = @"  ______      __                 _____                      _ _         
 / ____/_  __/ /_  ___  _____   / ___/____  ____ ___  ___  (_) |_ _   _ 
/ /   / / / / __ \/ _ \/ ___/   \__ \/ __ \/ __ `__ \/ _ \/ / __| | / /
/ /___/ /_/ / /_/ /  __/ /      ___/ / /_/ / / / / / /  __/ / |_ | |/ / 
\____/\__, /_.___/\___/_/      /____/ .___/_/ /_/ /_/\___/_/\__||___/  
     /____/                        /_/                                 ";

                using (Font asciiFont = new Font("Consolas", 8, FontStyle.Regular))
                {
                    g.DrawString(asciiArt, asciiFont, new SolidBrush(Color.FromArgb(0, 255, 200)), new PointF(0, 10));
                }
            }

            PictureBox pb = new PictureBox();
            pb.Image = bmp;
            return pb;
        }

        private void InitializeChatbot()
        {
            _user = new UserProfile();
            _memory = new ConversationMemory();

            // Get user name
            string name = Microsoft.VisualBasic.Interaction.InputBox(
                "Welcome to the Cybersecurity Awareness Bot!\n\nPlease enter your name:",
                "User Registration",
                "User");

            _user.Name = string.IsNullOrWhiteSpace(name) ? "Friend" : name.Trim();
            _memory.Remember("userName", _user.Name);

            _responseService = new ResponseService(_user, _memory);
        }

        private void PlayWelcomeAudio()
        {
            string audioPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "greeting.wav");
            if (File.Exists(audioPath))
            {
                AudioPlayer.PlaySoundAsync(audioPath);
            }
        }

        private void DisplayWelcomeMessage()
        {
            AppendBotMessage($"Hello {_user.Name}! 👋");
            AppendBotMessage("I'm your Cybersecurity Awareness Assistant.");
            AppendBotMessage("I can help you learn about:");
            AppendBotMessage("  • 🔐 Password safety");
            AppendBotMessage("  • 🎣 Phishing scams");
            AppendBotMessage("  • 🛡️ Online scams");
            AppendBotMessage("  • 🌐 Safe browsing");
            AppendBotMessage("  • 🔗 Suspicious links");
            AppendBotMessage("  • 🔒 Privacy protection");
            AppendSeparator();
            AppendBotMessage("Type 'help' to see all options, or just ask me anything!");
            AppendBotMessage("Tell me what topics you're interested in, and I'll remember! 💡");
            AppendSeparator();
        }

        private void BtnSend_Click(object sender, EventArgs e)
        {
            ProcessUserInput();
        }

        private void TxtUserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ProcessUserInput();
                e.SuppressKeyPress = true;
            }
        }

        private void ProcessUserInput()
        {
            string userInput = txtUserInput.Text.Trim();

            if (string.IsNullOrWhiteSpace(userInput))
            {
                AppendSystemMessage("Please type a message...");
                return;
            }

            // Display user message
            AppendUserMessage(userInput);
            txtUserInput.Clear();

            // Update status
            lblUserStatus.Text = "🤔 Bot is thinking...";
            lblUserStatus.ForeColor = Color.FromArgb(255, 200, 100);
            Application.DoEvents();

            // Get response from bot
            string response = _responseService.GetResponse(userInput);

            // Display bot response with typing effect simulation
            AppendBotMessage(response);

            // Update status
            lblUserStatus.Text = "✅ Ready to chat";
            lblUserStatus.ForeColor = Color.FromArgb(150, 150, 180);

            // Check for exit
            if (userInput.Equals("exit", StringComparison.OrdinalIgnoreCase))
            {
                btnSend.Enabled = false;
                txtUserInput.Enabled = false;
                btnClear.Text = "🏠 NEW SESSION";
                btnSend.Text = "👋 GOODBYE";

                AppendSystemMessage("Type 'new' to start a new conversation, or close the window.");
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtChatHistory.Clear();
            DisplayWelcomeMessage();
        }

        private void AppendUserMessage(string message)
        {
            txtChatHistory.SelectionColor = Color.FromArgb(100, 200, 255);
            txtChatHistory.SelectionFont = new Font("Segoe UI", 10, FontStyle.Bold);
            txtChatHistory.AppendText($"\n👤 {_user.Name}: ");
            txtChatHistory.SelectionColor = Color.White;
            txtChatHistory.SelectionFont = new Font("Segoe UI", 10, FontStyle.Regular);
            txtChatHistory.AppendText($"{message}\n");
            txtChatHistory.ScrollToCaret();
        }

        private void AppendBotMessage(string message)
        {
            txtChatHistory.SelectionColor = Color.FromArgb(0, 255, 200);
            txtChatHistory.SelectionFont = new Font("Segoe UI", 10, FontStyle.Bold);
            txtChatHistory.AppendText($"\n🤖 BOT: ");
            txtChatHistory.SelectionColor = Color.FromArgb(200, 255, 200);
            txtChatHistory.SelectionFont = new Font("Segoe UI", 10, FontStyle.Regular);
            txtChatHistory.AppendText($"{message}\n");
            txtChatHistory.ScrollToCaret();
        }

        private void AppendSystemMessage(string message)
        {
            txtChatHistory.SelectionColor = Color.FromArgb(255, 200, 100);
            txtChatHistory.SelectionFont = new Font("Segoe UI", 9, FontStyle.Italic);
            txtChatHistory.AppendText($"\n💡 {message}\n");
            txtChatHistory.ScrollToCaret();
        }

        private void AppendSeparator()
        {
            txtChatHistory.SelectionColor = Color.FromArgb(80, 80, 100);
            txtChatHistory.AppendText("\n────────────────────────────────────────────────────────────\n");
            txtChatHistory.ScrollToCaret();
        }
    }
}