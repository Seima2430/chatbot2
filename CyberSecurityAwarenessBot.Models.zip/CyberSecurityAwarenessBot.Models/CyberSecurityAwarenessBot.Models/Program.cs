﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CyberSecurityAwarenessBot.Models
{
    public class UserProfile
    {
        public string Name { get; set; } = string.Empty;
        public List<string> Interests { get; set; } = new List<string>();
        public string LastTopic { get; set; } = string.Empty;
        public DateTime ConversationStartTime { get; set; }
        public int MessagesExchanged { get; set; }

        public UserProfile()
        {
            ConversationStartTime = DateTime.Now;
            MessagesExchanged = 0;
        }

        public void AddInterest(string topic)
        {
            if (!Interests.Contains(topic))
            {
                Interests.Add(topic);
            }
        }

        public string GetPersonalizedGreeting()
        {
            if (Interests.Count > 0)
            {
                return $"Welcome back, {Name}! As someone interested in {string.Join(", ", Interests)}, let me share some relevant tips with you.";
            }
            return $"Good to see you again, {Name}!";
        }
    }
}
